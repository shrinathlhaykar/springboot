package com.demojioproject.spring.boot.employee.service;

import com.demojioproject.spring.boot.employee.entity.Employee;
import com.demojioproject.spring.boot.employee.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    @Autowired
    private EmployeeRepository employeeRepository;
    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public List<Employee> fetchEmployeeList() {
        return employeeRepository.findAll();
    }

    @Override
    public Optional<Employee> fetchEmployeeById(Long employeeId) {
        return employeeRepository.findById(employeeId);
    }

    @Override
    public void deleteEmployeeById(Long employeeId){
        employeeRepository.deleteById(employeeId);
    }

    @Override
    public Employee updateEmployeeById(Long employeeId, Employee employee) {
        Employee empDB= employeeRepository.findById(employeeId).get();

        if(Objects.nonNull(employee.getEmpFirstName())&&
                !"".equalsIgnoreCase(employee.getEmpFirstName())){
            empDB.setEmpFirstName(employee.getEmpFirstName());
        }

        if(Objects.nonNull(employee.getEmpLastName())&&
                !"".equalsIgnoreCase(employee.getEmpLastName())){
            empDB.setEmpLastName(employee.getEmpLastName());
        }

        if(Objects.nonNull(employee.getEmpEmailId())&&
                !"".equalsIgnoreCase(employee.getEmpEmailId())){
            empDB.setEmpEmailId(employee.getEmpEmailId());
        }

        if(Objects.nonNull(employee.getEmpDepartment())&&
                !"".equalsIgnoreCase(employee.getEmpDepartment())){
            empDB.setEmpDepartment(employee.getEmpDepartment());
        }


        if(Objects.nonNull(employee.getEmpMobile())&&
                !"".equalsIgnoreCase(employee.getEmpMobile())){
            empDB.setEmpMobile(employee.getEmpMobile());
        }

        if(Objects.nonNull(employee.getEmpPosition())&&
                !"".equalsIgnoreCase(employee.getEmpPosition())){
            empDB.setEmpPosition(employee.getEmpPosition());
        }

        return employeeRepository.save(empDB);
    }
}
