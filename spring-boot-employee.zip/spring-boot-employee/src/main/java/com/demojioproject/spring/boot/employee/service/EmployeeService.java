package com.demojioproject.spring.boot.employee.service;

import com.demojioproject.spring.boot.employee.entity.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    public Employee saveEmployee(Employee employee);

    public List<Employee> fetchEmployeeList();

    public Optional<Employee> fetchEmployeeById(Long employeeId);

    public void deleteEmployeeById(Long employeeId);

    public Employee updateEmployeeById(Long employeeId, Employee employee);
}
