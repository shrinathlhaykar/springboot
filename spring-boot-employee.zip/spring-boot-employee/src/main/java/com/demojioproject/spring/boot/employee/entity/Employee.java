package com.demojioproject.spring.boot.employee.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Employee {

    @Id
    @SequenceGenerator(name = "employee_sequence",
            sequenceName= "employee_sequence",
            allocationSize = 1)
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "employee_sequence"
    )
    private Long employeeId;

    private String empFirstName;
    private String empLastName;
    @Column(name = "email_address",
            nullable = false)
    private String empEmailId;
    private String empDepartment;
    private String empPosition;
    private String empMobile;
}
